#!/usr/bin/env python3
import os

def dec_to_bin(dec, bits=8):
    """
    Convert a signed or unsigned decimal string or int to two's-complement binary string of length `bits`.
    Accepts decimal strings like "-3", "5", or integers.
    """
    val = int(dec)
    if val < 0:
        # two's complement
        val = (1 << bits) + val
    if not (0 <= val < (1 << bits)):
        raise ValueError(f"value {dec} out of range for {bits} bits")
    return format(val, f"0{bits}b")

def regNum_to_bin(reg_num):
    """
    Accept 'r3', 'R3' or just '3' and convert to 4-bit register number string.
    """
    s = str(reg_num).strip()
    if s.lower().startswith("r"):
        s = s[1:]
    return format(int(s), "04b")

def is_label_token(tok):
    return str(tok).startswith(".")

def strip_label_token(tok):
    return str(tok).lstrip(".")

# Read source
with open("assembly.txt", "r") as f:
    raw_lines = f.readlines()

# Preprocess: remove trailing newline only lines, handle comments (use '#' as comment delimiter)
clean_lines = []
for raw in raw_lines:
    # remove newline and trailing spaces
    line = raw.rstrip("\n")
    # remove comments after '#'
    line = line.split("#", 1)[0]
    # collapse leading/trailing whitespace
    line = line.strip()
    # keep original raw line for eventual assembly output, but if empty after stripping comments/space -> keep empty for preservation
    clean_lines.append(line)

# First pass: collect labels and definitions; compute instruction addresses correctly
labels = {}
definitions = {}
instr_address = 0
for line in clean_lines:
    if line == "":
        continue
    parts = line.split()
    if len(parts) == 0:
        continue
    # label on its own or label followed by instruction
    if parts[0].startswith("."):
        label_name = strip_label_token(parts[0])
        # label points to the next instruction address (current instr_address)
        labels[label_name] = instr_address
        # if only a label on the line, continue (no instruction)
        if len(parts) == 1:
            continue
        # otherwise drop the label token and continue parsing this line as an instruction
        parts = parts[1:]

    # definition lines: allow either "define NAME value" or "define NAME = value"
    if parts[0].lower() == "define":
        if len(parts) < 3:
            raise ValueError(f"bad define directive: {line}")
        name = parts[1]
        # value could be like "5" or "-1" or "0xFF"
        val_token = parts[-1]
        # allow hex 0x format
        if isinstance(val_token, str) and val_token.lower().startswith("0x"):
            val = int(val_token, 16)
        else:
            val = int(val_token)
        # store as 8-bit binary string (definitions used by LDI/ADI)
        definitions[name] = format(val & 0xFF, "08b")
        # definitions are not instructions
        continue

    # otherwise it's an instruction -> increment address
    instr_address += 1

# --- Debug prints (optional) ---
# print("Labels:", labels)
# print("Definitions:", definitions)

# Second pass: assemble
machine_code = []
# We'll preserve original line texts for writing back assembly file later
for line in clean_lines:
    if line == "":
        # keep an empty slot (we'll skip writing empty machine code lines later)
        machine_code.append("")  # keep parity with original flow
        continue
    parts = line.split()
    if len(parts) == 0:
        machine_code.append("")
        continue

    # Handle label at start of line (label + instruction on same line)
    if parts[0].startswith("."):
        if len(parts) == 1:
            # pure label line - no machine code
            machine_code.append("")
            continue
        parts = parts[1:]
        if len(parts) == 0:
            machine_code.append("")
            continue

    opcode = parts[0].upper()
    mc = None  # machine-code line (16-bit string)

    def get_imm_token(tok):
        # Accept label (starting with '.'), label name (no dot), numeric decimal, or hex (0x..), or definition name
        if tok in definitions:
            return definitions[tok]
        if tok.startswith("."):
            lbl = strip_label_token(tok)
            if lbl not in labels:
                raise KeyError(f"unknown label: {tok}")
            return format(int(labels[lbl]), "010b")  # return 10-bit binary for branch/jmp usage where needed
        if tok.lower().startswith("0x"):
            return str(int(tok, 16))
        return tok  # numeric string; caller will convert/format as needed

    try:
        if opcode == "NOP":
            mc = "0000000000000000"
        elif opcode == "HLT":
            mc = "0001000000000000"
        elif opcode == "ADD":
            mc = "0010" + regNum_to_bin(parts[1]) + regNum_to_bin(parts[2]) + regNum_to_bin(parts[3])
        elif opcode == "SUB":
            mc = "0011" + regNum_to_bin(parts[1]) + regNum_to_bin(parts[2]) + regNum_to_bin(parts[3])
        elif opcode == "NOR":
            mc = "0100" + regNum_to_bin(parts[1]) + regNum_to_bin(parts[2]) + regNum_to_bin(parts[3])
        elif opcode == "AND":
            mc = "0101" + regNum_to_bin(parts[1]) + regNum_to_bin(parts[2]) + regNum_to_bin(parts[3])
        elif opcode == "XOR":
            mc = "0110" + regNum_to_bin(parts[1]) + regNum_to_bin(parts[2]) + regNum_to_bin(parts[3])
        elif opcode == "RSH":
            # RSH dst, amount   (original used reg, 0000, reg)
            mc = "0111" + regNum_to_bin(parts[1]) + "0000" + regNum_to_bin(parts[2])
        elif opcode == "LDI":
            # LDI reg imm_or_def
            dest = regNum_to_bin(parts[1])
            token = parts[2]
            if token in definitions:
                imm_bin = definitions[token]  # already 8-bit binary
            else:
                imm_bin = dec_to_bin(token, bits=8)
            mc = "1000" + dest + imm_bin
        elif opcode == "ADI":
            dest = regNum_to_bin(parts[1])
            token = parts[2]
            if token in definitions:
                imm_bin = definitions[token]
            else:
                imm_bin = dec_to_bin(token, bits=8)
            mc = "1001" + dest + imm_bin
        elif opcode == "INC":
            dest = regNum_to_bin(parts[1])
            mc = "1001" + dest + "00000001"
        elif opcode == "DEC":
            dest = regNum_to_bin(parts[1])
            mc = "1001" + dest + "11111111"
        elif opcode == "JMP":
            # JMP target  (target can be numeric or label)
            target = parts[1]
            if target.startswith("."):
                lbl = strip_label_token(target)
                if lbl not in labels:
                    raise KeyError(f"unknown label: {target}")
                addr_bin = format(int(labels[lbl]), "010b")
            elif target in labels:
                addr_bin = format(int(labels[target]), "010b")
            else:
                addr_bin = format(int(target), "010b")
            mc = "1010" + "00" + addr_bin
        elif opcode == "BRH":
            # BRH condition target
            cond = parts[1].lower()
            target = parts[2]
            # map cond to two-bit code
            cond_map = {"zero": "00", "=": "00", "notzero": "01", "!=": "01", "carry": "10", ">=": "10", "notcarry": "11", "<": "11"}
            if cond not in cond_map:
                raise ValueError(f"unknown branch condition: {cond}")
            cond_bits = cond_map[cond]
            if target.startswith("."):
                lbl = strip_label_token(target)
                if lbl not in labels:
                    raise KeyError(f"unknown label: {target}")
                addr_bin = format(int(labels[lbl]), "010b")
            elif target in labels:
                addr_bin = format(int(labels[target]), "010b")
            else:
                addr_bin = format(int(target), "010b")
            mc = "1011" + cond_bits + addr_bin
        elif opcode == "CMP":
            mc = "0011" + regNum_to_bin(parts[1]) + regNum_to_bin(parts[2]) + "0000"
        elif opcode == "CAL":
            # call target (like JMP but different opcode)
            target = parts[1]
            if target.startswith("."):
                lbl = strip_label_token(target)
                if lbl not in labels:
                    raise KeyError(f"unknown label: {target}")
                addr_bin = format(int(labels[lbl]), "010b")
            elif target in labels:
                addr_bin = format(int(labels[target]), "010b")
            else:
                addr_bin = format(int(target), "010b")
            mc = "1100" + "00" + addr_bin
        elif opcode == "RET":
            mc = "1101" + "000000000000"
        elif opcode == "LOD":
            # LOD dst, base_reg[, offset]
            # formats: LOD dst base offset   (offset optional signed -4..+3 assumed 3-bit)
            dst = regNum_to_bin(parts[1])
            base = regNum_to_bin(parts[2])
            if len(parts) >= 4:
                off_tok = parts[3]
                off_int = int(off_tok)
                # Encode 4-bit offset: top bit indicates sign (1 = negative), lower 3 bits magnitude as in your original
                if off_int < 0:
                    # store 1 + (off + 8) in 4 bits
                    off_bin = "1" + format((off_int + 8) & 0x7, "03b")
                else:
                    off_bin = "0" + format(off_int & 0x7, "03b")
                mc = "1110" + dst + base + off_bin
            else:
                mc = "1110" + dst + base + "0000"
        elif opcode == "STR":
            dst = regNum_to_bin(parts[1])
            base = regNum_to_bin(parts[2])
            if len(parts) >= 4:
                off_tok = parts[3]
                off_int = int(off_tok)
                if off_int < 0:
                    off_bin = "1" + format((off_int + 8) & 0x7, "03b")
                else:
                    off_bin = "0" + format(off_int & 0x7, "03b")
                mc = "1111" + dst + base + off_bin
            else:
                mc = "1111" + dst + base + "0000"
        else:
            # Unknown/unsupported opcode
            raise ValueError(f"Unknown opcode: {opcode}")

    except IndexError:
        raise IndexError(f"missing operands for opcode '{opcode}' on line: '{line}'")
    except Exception:
        # Re-raise to show a helpful message; in production you might want to handle more gracefully
        raise

    if mc is None:
        machine_code.append("")
    else:
        # sanity check length
        if len(mc) != 16:
            raise ValueError(f"Generated machine code length {len(mc)} != 16 for line: {line}\nmc={mc}")
        machine_code.append(mc)

# Output: prompt for program name and write files; ensure directories exist
program_name = input("Enter your program name: ").strip()
os.makedirs("machinecodes", exist_ok=True)
os.makedirs("assembly", exist_ok=True)

with open(os.path.join("machinecodes", program_name + "_mc.txt"), "w") as f_mc:
    for mc in machine_code:
        if mc == "" or mc is None:
            continue
        print(mc)
        f_mc.write(mc + "\n")

with open(os.path.join("assembly", program_name + "_as.txt"), "w") as f_as:
    # write original raw lines (not fully stripped of comments/newlines) — use the original raw_lines list
    for raw in raw_lines:
        f_as.write(raw)
