# TinyLang - High-Level Language Compiler for 8-bit CPU

A simple compiler that translates a high-level language to assembly for your custom 8-bit CPU.

## Features

### Current Language Support
- **Variables**: 8-bit integers (0-255)
- **Arithmetic**: `+`, `-`, `&` (bitwise AND), `^` (bitwise XOR)
- **Control Flow**: `if` statements and `while` loops
- **I/O**: `print(var)` to display on number display (address 252)
- **Comments**: Lines starting with `#`

### Syntax Examples

```tinylang
# Variable assignment
x = 10
y = 5

# Arithmetic operations
sum = x + y
diff = x - y
bitand = x & y
bitxor = x ^ y

# Mixed operations (immediate values)
result = x + 5
result = x - 3

# Print to number display
print(result)

# If statement (checks if variable is non-zero)
if (result) {
    x = 1
}

# While loop (loops while variable is non-zero)
counter = 10
while (counter) {
    counter = counter - 1
}
```

## Usage

### Compile a Program

```bash
python3 tlc.py program.tl
```

This generates `program.asm` assembly file.

Or specify output file:

```bash
python3 tlc.py program.tl output.asm
```

### Example Program

See `example.tl` - calculates sum of 1 to 10:

```tinylang
sum = 0
counter = 1
limit = 10

while (counter) {
    sum = sum + counter
    counter = counter + 1
    
    temp = counter - limit
    if (temp) {
        counter = 0
    }
}

print(sum)
```

## How It Works

1. **Parser** (`tinylang_parser.py`): Converts source code into statements
2. **Compiler** (`tinylang_compiler.py`): Translates statements to assembly
3. **Memory Allocation**: Automatically assigns variables to data memory (addresses 0-245)
4. **Register Usage**: Uses r1-r4 as working registers for operations
5. **Label Generation**: Creates unique labels for control flow

## Architecture

### Memory Layout
- **0-245**: Variable storage (246 variables max!)
- **246-251**: Screen/pixel I/O (reserved)
- **252-254**: Number display and controller I/O
- **255**: Controller input

### Register Usage
- **r0**: Always zero (hardwired)
- **r1**: Accumulator (main working register)
- **r2**: Operand register (for binary operations)
- **r3**: Temporary register
- **r4**: Memory pointer (for LOD/STR instructions)
- **r5-r15**: Available for future use

## Current Limitations

- Maximum 246 variables (addresses 0-245)
- Only 8-bit unsigned integers (0-255)
- No functions/procedures yet
- No arrays (but you have 246 separate variables!)
- Conditions only check non-zero vs zero
- No comparison operators (<, >, ==) yet

## Advantages Over Register-Only

✓ **246 variables** instead of just 15!
✓ More flexible - registers used only for computation
✓ Easier to add features like arrays and pointers later
✓ Variables persist in memory naturally

## Future Enhancements

Possible additions:
- Comparison operators (==, !=, <, >, <=, >=)
- Else clauses for if statements
- For loops
- Functions/subroutines with parameters
- Arrays and pointers
- More operators (OR, NOT, left shift)
- Screen/pixel manipulation
- Controller input reading
- Optimization passes

## Files

- `tlc.py` - Main compiler executable
- `tinylang_parser.py` - Parser for TinyLang syntax
- `tinylang_compiler.py` - Code generator for assembly
- `example.tl` - Example program
- `example.asm` - Generated assembly output

## Memory-Mapped I/O

The compiler automatically handles:
- Address 252: Number display (via `print()` function)

Future: Support for screen, pixel, and controller I/O

## Architecture Notes

Generated assembly is compatible with your 8-bit CPU featuring:
- 16 registers (r0-r15)
- 256 bytes data memory
- 1024 instruction memory
- Flags: Zero, Carry
- Memory-mapped I/O
