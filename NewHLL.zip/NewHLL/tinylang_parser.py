"""
TinyLang Parser
Parses TinyLang syntax into statements for the compiler

Syntax:
  var = value
  var = var2 + var3
  var = var2 - 10
  print(var)
  if (var) {
    statements...
  }
  while (var) {
    statements...
  }
"""

import re

class Parser:
    def __init__(self):
        self.tokens = []
        self.pos = 0
    
    def tokenize(self, code):
        """Split code into tokens"""
        # Remove comments
        code = re.sub(r'#.*', '', code)
        
        # Define token patterns
        patterns = [
            (r'==', 'EQUALS_EQUALS'),
            (r'!=', 'NOT_EQUALS'),
            (r'<=', 'LESS_EQUALS'),
            (r'>=', 'GREATER_EQUALS'),
            (r'<', 'LESS_THAN'),
            (r'>', 'GREATER_THAN'),
            (r'\d+', 'NUMBER'),
            (r'[a-zA-Z_][a-zA-Z0-9_]*', 'IDENTIFIER'),
            (r'\+', 'PLUS'),
            (r'-', 'MINUS'),
            (r'\&', 'AND'),
            (r'\^', 'XOR'),
            (r'\|', 'OR'),
            (r'~', 'NOT'),
            (r'=', 'EQUALS'),
            (r'\(', 'LPAREN'),
            (r'\)', 'RPAREN'),
            (r'\{', 'LBRACE'),
            (r'\}', 'RBRACE'),
            (r',', 'COMMA'),
            (r'\s+', 'WHITESPACE'),
        ]
        
        tokens = []
        i = 0
        while i < len(code):
            matched = False
            for pattern, token_type in patterns:
                regex = re.match(pattern, code[i:])
                if regex:
                    value = regex.group(0)
                    if token_type != 'WHITESPACE':
                        tokens.append((token_type, value))
                    i += len(value)
                    matched = True
                    break
            if not matched:
                raise Exception(f"Unexpected character: {code[i]}")
        
        return tokens
    
    def peek(self, offset=0):
        """Look at current token without consuming"""
        pos = self.pos + offset
        if pos < len(self.tokens):
            return self.tokens[pos]
        return None
    
    def consume(self, expected_type=None):
        """Consume and return current token"""
        if self.pos >= len(self.tokens):
            raise Exception("Unexpected end of input")
        
        token = self.tokens[self.pos]
        if expected_type and token[0] != expected_type:
            raise Exception(f"Expected {expected_type}, got {token[0]}")
        
        self.pos += 1
        return token
    
    def parse_expression(self):
        """Parse an expression (variable, number, or binary operation)"""
        left_token = self.peek()
        
        if left_token[0] == 'NUMBER':
            self.consume()
            return int(left_token[1])
        elif left_token[0] == 'IDENTIFIER':
            self.consume()
            var_name = left_token[1]
            
            # Check for binary operation
            op_token = self.peek()
            if op_token and op_token[0] in ['PLUS', 'MINUS', 'AND', 'XOR', 'OR']:
                self.consume()
                op_map = {
                    'PLUS': '+',
                    'MINUS': '-',
                    'AND': '&',
                    'XOR': '^',
                    'OR': '|'
                }
                op = op_map[op_token[0]]
                
                right_token = self.consume()
                if right_token[0] == 'NUMBER':
                    right = int(right_token[1])
                elif right_token[0] == 'IDENTIFIER':
                    right = right_token[1]
                else:
                    raise Exception(f"Expected number or variable, got {right_token[0]}")
                
                return ('arithmetic', var_name, op, right)
            else:
                # Just a variable reference
                return var_name
        else:
            raise Exception(f"Unexpected token in expression: {left_token}")
    
    def parse_statement(self):
        """Parse a single statement"""
        token = self.peek()
        
        if token[0] == 'IDENTIFIER':
            # Could be assignment, function call, or a keyword
            if token[1] == 'func':
                # Function definition: func add(a b) { ... }
                self.consume()  # 'func'
                func_name = self.consume('IDENTIFIER')[1]
                self.consume('LPAREN')
                
                # Parse parameters
                params = []
                while self.peek()[0] != 'RPAREN':
                    param = self.consume('IDENTIFIER')[1]
                    params.append(param)
                    # No comma required between params for simplicity
                
                self.consume('RPAREN')
                self.consume('LBRACE')
                
                # Parse function body
                body = []
                while self.peek()[0] != 'RBRACE':
                    body.append(self.parse_statement())
                
                self.consume('RBRACE')
                return ('func_def', func_name, params, body)
            
            elif token[1] == 'return':
                # Return statement: return x or return x + y
                self.consume()  # 'return'
                expr = self.parse_expression()
                return ('return', expr)
            
            # Check if next token is assignment or function call
            next_token = self.peek(1)
            
            if next_token and next_token[0] == 'EQUALS':
                # Could be: var = value OR var = call func(args)
                var_name = self.consume('IDENTIFIER')[1]
                self.consume('EQUALS')
                
                # Check if it's a function call assignment
                if self.peek()[0] == 'IDENTIFIER' and self.peek()[1] == 'call':
                    self.consume()  # 'call'
                    func_name = self.consume('IDENTIFIER')[1]
                    self.consume('LPAREN')
                    
                    # Parse arguments
                    args = []
                    while self.peek()[0] != 'RPAREN':
                        arg_token = self.peek()
                        if arg_token[0] == 'NUMBER':
                            self.consume()
                            args.append(int(arg_token[1]))
                        else:
                            arg = self.consume('IDENTIFIER')[1]
                            args.append(arg)
                    
                    self.consume('RPAREN')
                    return ('func_call_assign', var_name, func_name, args)
                else:
                    # Regular assignment
                    expr = self.parse_expression()
                    
                    if isinstance(expr, tuple) and expr[0] == 'arithmetic':
                        # var = left op right
                        _, left, op, right = expr
                        return ('arithmetic', var_name, left, op, right)
                    else:
                        # var = value or var = var2
                        return ('assign', var_name, expr)
            
            elif token[1] == 'call':
                # Function call without assignment: call func(args)
                self.consume()  # 'call'
                func_name = self.consume('IDENTIFIER')[1]
                self.consume('LPAREN')
                
                args = []
                while self.peek()[0] != 'RPAREN':
                    arg_token = self.peek()
                    if arg_token[0] == 'NUMBER':
                        self.consume()
                        args.append(int(arg_token[1]))
                    else:
                        arg = self.consume('IDENTIFIER')[1]
                        args.append(arg)
                
                self.consume('RPAREN')
                return ('func_call', func_name, args)
            # Could be assignment or a keyword
            if token[1] == 'print':
                self.consume()  # 'print'
                self.consume('LPAREN')
                
                # Parse the expression inside print()
                expr = self.parse_expression()
                
                self.consume('RPAREN')
                
                # If it's a simple variable, return print statement
                if isinstance(expr, str):
                    return ('print', expr)
                # If it's an immediate number, create a print_immediate statement
                elif isinstance(expr, int):
                    return ('print_immediate', expr)
                # If it's an arithmetic expression, we need to compute it first
                elif isinstance(expr, tuple) and expr[0] == 'arithmetic':
                    # Create a temporary variable for the result
                    temp_var = f"_temp_{id(expr)}"
                    _, left, op, right = expr
                    return ('print_expr', temp_var, left, op, right)
                else:
                    raise Exception(f"Unexpected expression in print: {expr}")
            
            elif token[1] == 'read_controller':
                self.consume()  # 'read_controller'
                self.consume('LPAREN')
                var_token = self.consume('IDENTIFIER')
                self.consume('RPAREN')
                return ('read_controller', var_token[1])
            
            elif token[1] == 'clear_display':
                self.consume()  # 'clear_display'
                self.consume('LPAREN')
                self.consume('RPAREN')
                return ('clear_display',)
            
            elif token[1] == 'clear_number_display':
                self.consume()  # 'clear_number_display'
                self.consume('LPAREN')
                self.consume('RPAREN')
                return ('clear_number_display',)
            
            elif token[1] == 'set_pixel':
                self.consume()  # 'set_pixel'
                self.consume('LPAREN')
                
                # Parse x expression
                x_expr = self.parse_expression()
                # Parse y expression
                y_expr = self.parse_expression()
                # Parse val expression
                val_expr = self.parse_expression()
                
                self.consume('RPAREN')
                return ('set_pixel', x_expr, y_expr, val_expr)
            
            elif token[1] == 'refresh_screen':
                self.consume()  # 'refresh_screen'
                self.consume('LPAREN')
                self.consume('RPAREN')
                return ('refresh_screen',)
            
            elif token[1] == 'clear_screen':
                self.consume()  # 'clear_screen'
                self.consume('LPAREN')
                self.consume('RPAREN')
                return ('clear_screen',)
                self.consume()  # 'print'
                self.consume('LPAREN')
                
                # Parse the expression inside print()
                expr = self.parse_expression()
                
                self.consume('RPAREN')
                
                # If it's a simple variable, return print statement
                if isinstance(expr, str):
                    return ('print', expr)
                # If it's an immediate number, create a print_immediate statement
                elif isinstance(expr, int):
                    return ('print_immediate', expr)
                # If it's an arithmetic expression, we need to compute it first
                elif isinstance(expr, tuple) and expr[0] == 'arithmetic':
                    # Create a temporary variable for the result
                    temp_var = f"_temp_{id(expr)}"
                    _, left, op, right = expr
                    return ('print_expr', temp_var, left, op, right)
                else:
                    raise Exception(f"Unexpected expression in print: {expr}")
            
            elif token[1] == 'if':
                self.consume()  # 'if'
                self.consume('LPAREN')
                
                # Check if this is a comparison or simple condition
                first_token = self.consume('IDENTIFIER')
                next_token = self.peek()
                
                if next_token and next_token[0] in ['EQUALS_EQUALS', 'NOT_EQUALS', 'LESS_THAN', 
                                                      'GREATER_THAN', 'LESS_EQUALS', 'GREATER_EQUALS']:
                    # It's a comparison: if (a < b)
                    op_token = self.consume()
                    op_map = {
                        'EQUALS_EQUALS': '==',
                        'NOT_EQUALS': '!=',
                        'LESS_THAN': '<',
                        'GREATER_THAN': '>',
                        'LESS_EQUALS': '<=',
                        'GREATER_EQUALS': '>='
                    }
                    op = op_map[op_token[0]]
                    
                    right_token = self.peek()
                    if right_token[0] == 'NUMBER':
                        self.consume()
                        right = int(right_token[1])
                    else:
                        right_token = self.consume('IDENTIFIER')
                        right = right_token[1]
                    
                    self.consume('RPAREN')
                    self.consume('LBRACE')
                    
                    # Parse body
                    body = []
                    while self.peek()[0] != 'RBRACE':
                        body.append(self.parse_statement())
                    
                    self.consume('RBRACE')
                    return ('if_compare', first_token[1], op, right, body)
                else:
                    # Simple condition: if (x)
                    self.consume('RPAREN')
                    self.consume('LBRACE')
                    
                    # Parse body
                    body = []
                    while self.peek()[0] != 'RBRACE':
                        body.append(self.parse_statement())
                    
                    self.consume('RBRACE')
                    return ('if', first_token[1], body)
            
            elif token[1] == 'ifzero':
                self.consume()  # 'ifzero'
                self.consume('LPAREN')
                cond_token = self.consume('IDENTIFIER')
                self.consume('RPAREN')
                self.consume('LBRACE')
                
                # Parse body
                body = []
                while self.peek()[0] != 'RBRACE':
                    body.append(self.parse_statement())
                
                self.consume('RBRACE')
                return ('ifzero', cond_token[1], body)
            
            elif token[1] == 'while':
                self.consume()  # 'while'
                self.consume('LPAREN')
                
                # Check if this is a comparison or simple condition
                first_token = self.consume('IDENTIFIER')
                next_token = self.peek()
                
                if next_token and next_token[0] in ['EQUALS_EQUALS', 'NOT_EQUALS', 'LESS_THAN', 
                                                      'GREATER_THAN', 'LESS_EQUALS', 'GREATER_EQUALS']:
                    # It's a comparison: while (a < b)
                    op_token = self.consume()
                    op_map = {
                        'EQUALS_EQUALS': '==',
                        'NOT_EQUALS': '!=',
                        'LESS_THAN': '<',
                        'GREATER_THAN': '>',
                        'LESS_EQUALS': '<=',
                        'GREATER_EQUALS': '>='
                    }
                    op = op_map[op_token[0]]
                    
                    right_token = self.peek()
                    if right_token[0] == 'NUMBER':
                        self.consume()
                        right = int(right_token[1])
                    else:
                        right_token = self.consume('IDENTIFIER')
                        right = right_token[1]
                    
                    self.consume('RPAREN')
                    self.consume('LBRACE')
                    
                    # Parse body
                    body = []
                    while self.peek()[0] != 'RBRACE':
                        body.append(self.parse_statement())
                    
                    self.consume('RBRACE')
                    return ('while_compare', first_token[1], op, right, body)
                else:
                    # Simple condition: while (x)
                    self.consume('RPAREN')
                    self.consume('LBRACE')
                    
                    # Parse body
                    body = []
                    while self.peek()[0] != 'RBRACE':
                        body.append(self.parse_statement())
                    
                    self.consume('RBRACE')
                    return ('while', first_token[1], body)
            
            # If we reach here, unknown identifier statement
            raise Exception(f"Unexpected identifier statement: {token[1]}")
        
        raise Exception(f"Unexpected token: {token}")
    
    def parse(self, code):
        """Parse complete program"""
        self.tokens = self.tokenize(code)
        self.pos = 0
        
        statements = []
        while self.pos < len(self.tokens):
            statements.append(self.parse_statement())
        
        return statements


# This module is imported by tlc.py - no standalone execution needed
if __name__ == "__main__":
    print("This is a library module. Use tlc.py to compile TinyLang programs.")
    print("Example: python3 tlc.py myprogram.tl")
