"""
TinyLang Compiler for 8-bit CPU
Compiles a simple high-level language to assembly
"""

class Compiler:
    def __init__(self):
        self.variables = {}  # Maps variable names to memory addresses
        self.next_memory_address = 0  # Start at memory address 0
        self.label_counter = 0
        self.assembly_code = []
        self.functions = {}  # Maps function names to (params, body, label)
        self.in_function = False
        self.current_function_params = []
        
        # Reserve working registers
        # r0 = zero register (hardwired)
        # r1 = general purpose / accumulator
        # r2 = general purpose / operand
        # r3 = temporary / result
        # r4 = memory pointer
        # r5 = return value register
        # r6 = function call temporary
        self.REG_ACC = "r1"      # Accumulator
        self.REG_OPERAND = "r2"  # Operand register
        self.REG_TEMP = "r3"     # Temporary
        self.REG_PTR = "r4"      # Memory pointer
        self.REG_RETURN = "r5"   # Return value
        self.REG_CALL_TEMP = "r6" # Function call temporary
        
    def new_label(self, prefix="L"):
        """Generate a unique label"""
        label = f".{prefix}{self.label_counter}"
        self.label_counter += 1
        return label
    
    def allocate_memory(self, var_name):
        """Allocate memory address for a variable"""
        if var_name not in self.variables:
            # Reserve addresses 0-245 for variables (246+ used for I/O)
            if self.next_memory_address >= 246:
                raise Exception("Out of memory! (max 246 variables)")
            self.variables[var_name] = self.next_memory_address
            self.next_memory_address += 1
        return self.variables[var_name]
    
    def get_memory_address(self, var_name):
        """Get the memory address for a variable"""
        if var_name not in self.variables:
            raise Exception(f"Variable '{var_name}' not declared")
        return self.variables[var_name]
    
    def emit(self, instruction):
        """Add an instruction to the assembly code"""
        self.assembly_code.append(instruction)
    
    def load_variable(self, var_name, dest_reg):
        """Load variable from memory into register"""
        addr = self.get_memory_address(var_name)
        
        # Check if we can use offset (-8 to 7 range)
        # Using r0 as base pointer (address 0) + offset
        if -8 <= addr <= 7:
            if addr >= 0:
                self.emit(f"LOD r0 {dest_reg} {addr}")
            else:
                self.emit(f"LOD r0 {dest_reg} {addr}")
        else:
            # For addresses outside offset range, use pointer register
            self.emit(f"LDI {self.REG_PTR} {addr}")
            self.emit(f"LOD {self.REG_PTR} {dest_reg}")
    
    def store_variable(self, var_name, src_reg):
        """Store register value into variable in memory"""
        addr = self.get_memory_address(var_name)
        
        # Check if we can use offset (-8 to 7 range)
        # Using r0 as base pointer (address 0) + offset
        if -8 <= addr <= 7:
            if addr >= 0:
                self.emit(f"STR r0 {src_reg} {addr}")
            else:
                self.emit(f"STR r0 {src_reg} {addr}")
        else:
            # For addresses outside offset range, use pointer register
            self.emit(f"LDI {self.REG_PTR} {addr}")
            self.emit(f"STR {self.REG_PTR} {src_reg}")
    
    def compile_assignment(self, var_name, value):
        """Compile: var = value"""
        # Allocate memory for variable
        addr = self.allocate_memory(var_name)
        
        if isinstance(value, int):
            # Direct value assignment: var = 10
            self.emit(f"LDI {self.REG_ACC} {value}")
            # Store using offset if possible
            if -8 <= addr <= 7:
                self.emit(f"STR r0 {self.REG_ACC} {addr}")
            else:
                self.emit(f"LDI {self.REG_PTR} {addr}")
                self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
        else:
            # Variable assignment: var1 = var2
            self.load_variable(value, self.REG_ACC)
            self.store_variable(var_name, self.REG_ACC)
    
    def compile_arithmetic(self, result_var, left_var, op, right_operand):
        """Compile: result = left op right"""
        # Allocate memory for result variable
        self.allocate_memory(result_var)
        
        # Load left operand into accumulator
        self.load_variable(left_var, self.REG_ACC)
        
        if isinstance(right_operand, int):
            # Immediate operation: var = var + 5
            if op == '+':
                self.emit(f"ADI {self.REG_ACC} {right_operand}")
            elif op == '-':
                # Subtract by adding two's complement
                complement = (256 - right_operand) % 256
                self.emit(f"ADI {self.REG_ACC} {complement}")
            else:
                # For bitwise ops with immediate, need to load immediate first
                self.emit(f"LDI {self.REG_OPERAND} {right_operand}")
                if op == '&':
                    self.emit(f"AND {self.REG_ACC} {self.REG_OPERAND} {self.REG_ACC}")
                elif op == '^':
                    self.emit(f"XOR {self.REG_ACC} {self.REG_OPERAND} {self.REG_ACC}")
                elif op == '|':
                    # OR using NOR: A OR B = NOT(NOT A AND NOT B) = NOR(NOR(A,A), NOR(B,B))
                    # Or simpler: A OR B can be done with: NOT(NOR(A, B))
                    self.emit(f"NOR {self.REG_ACC} {self.REG_OPERAND} {self.REG_TEMP}")
                    self.emit(f"NOR {self.REG_TEMP} {self.REG_TEMP} {self.REG_ACC}")
                else:
                    raise Exception(f"Operation {op} not supported")
        else:
            # Register operation: var1 = var2 + var3
            self.load_variable(right_operand, self.REG_OPERAND)
            
            if op == '+':
                self.emit(f"ADD {self.REG_ACC} {self.REG_OPERAND} {self.REG_ACC}")
            elif op == '-':
                self.emit(f"SUB {self.REG_ACC} {self.REG_OPERAND} {self.REG_ACC}")
            elif op == '&':
                self.emit(f"AND {self.REG_ACC} {self.REG_OPERAND} {self.REG_ACC}")
            elif op == '^':
                self.emit(f"XOR {self.REG_ACC} {self.REG_OPERAND} {self.REG_ACC}")
            elif op == '|':
                # OR using NOR: NOT(NOR(A, B))
                self.emit(f"NOR {self.REG_ACC} {self.REG_OPERAND} {self.REG_TEMP}")
                self.emit(f"NOR {self.REG_TEMP} {self.REG_TEMP} {self.REG_ACC}")
            else:
                raise Exception(f"Operation {op} not supported")
        
        # Store result back to memory
        self.store_variable(result_var, self.REG_ACC)
    
    def compile_print(self, var_name):
        """Compile: print(var) - displays on number display"""
        # Load variable value
        self.load_variable(var_name, self.REG_ACC)
        
        # Memory address 252 is the number display
        self.emit(f"LDI {self.REG_PTR} 252")
        self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
    
    def compile_print_immediate(self, value):
        """Compile: print(123) - displays immediate value"""
        # Load immediate value
        self.emit(f"LDI {self.REG_ACC} {value}")
        
        # Memory address 252 is the number display
        self.emit(f"LDI {self.REG_PTR} 252")
        self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
    
    def compile_print_expr(self, temp_var, left_var, op, right_operand):
        """Compile: print(expr) - evaluates expression then displays it"""
        # First compute the expression into a temporary variable
        self.compile_arithmetic(temp_var, left_var, op, right_operand)
        # Then print that temporary variable
        self.compile_print(temp_var)
    
    def compile_read_controller(self, var_name):
        """Compile: read_controller(var) - reads controller input"""
        # Allocate memory for variable
        self.allocate_memory(var_name)
        
        # Memory address 255 is controller input
        self.emit(f"LDI {self.REG_PTR} 255")
        self.emit(f"LOD {self.REG_PTR} {self.REG_ACC}")
        self.store_variable(var_name, self.REG_ACC)
    
    def compile_clear_display(self):
        """Compile: clear_display() - clears number display"""
        # Memory address 253 is clear number display
        self.emit(f"LDI {self.REG_ACC} 1")
        self.emit(f"LDI {self.REG_PTR} 253")
        self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
    
    def compile_clear_number_display(self):
        """Compile: clear_number_display() - initializes number display registers to 0"""
        # Set Show Number (252) to 0
        self.emit(f"LDI {self.REG_ACC} 0")
        self.emit(f"LDI {self.REG_PTR} 252")
        self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
        
        # Set Clear Number (253) to 0
        self.emit(f"LDI {self.REG_PTR} 253")
        self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
        
        # Set Signed Mode (254) to 0
        self.emit(f"LDI {self.REG_PTR} 254")
        self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
    
    def compile_set_pixel(self, x_expr, y_expr, val_expr):
        """Compile: set_pixel(x, y, value) - sets a pixel on screen"""
        # Handle y coordinate FIRST (will go in top 4 bits)
        if isinstance(y_expr, int):
            self.emit(f"LDI {self.REG_ACC} {y_expr}")
        elif isinstance(y_expr, str):
            self.load_variable(y_expr, self.REG_ACC)
        elif isinstance(y_expr, tuple) and y_expr[0] == 'arithmetic':
            # Compute expression: y + 1
            _, left, op, right = y_expr
            self.load_variable(left, self.REG_ACC)
            if isinstance(right, int):
                if op == '+':
                    self.emit(f"ADI {self.REG_ACC} {right}")
                elif op == '-':
                    complement = (256 - right) % 256
                    self.emit(f"ADI {self.REG_ACC} {complement}")
                else:
                    self.emit(f"LDI {self.REG_OPERAND} {right}")
                    self.apply_operator(op, self.REG_ACC, self.REG_OPERAND, self.REG_ACC)
            else:
                self.load_variable(right, self.REG_OPERAND)
                self.apply_operator(op, self.REG_ACC, self.REG_OPERAND, self.REG_ACC)
        
        # Save y result to temp (we need REG_ACC for x)
        self.emit(f"ADD {self.REG_ACC} r0 {self.REG_CALL_TEMP}")
        
        # Handle x coordinate SECOND (will go in bottom 4 bits)
        if isinstance(x_expr, int):
            self.emit(f"LDI {self.REG_OPERAND} {x_expr}")
        elif isinstance(x_expr, str):
            self.load_variable(x_expr, self.REG_OPERAND)
        elif isinstance(x_expr, tuple) and x_expr[0] == 'arithmetic':
            _, left, op, right = x_expr
            self.load_variable(left, self.REG_OPERAND)
            if isinstance(right, int):
                if op == '+':
                    self.emit(f"ADI {self.REG_OPERAND} {right}")
                elif op == '-':
                    complement = (256 - right) % 256
                    self.emit(f"ADI {self.REG_OPERAND} {complement}")
                else:
                    self.emit(f"LDI {self.REG_ACC} {right}")
                    self.apply_operator(op, self.REG_OPERAND, self.REG_ACC, self.REG_OPERAND)
            else:
                self.load_variable(right, self.REG_ACC)
                self.apply_operator(op, self.REG_OPERAND, self.REG_ACC, self.REG_OPERAND)
        
        # Combine y and x: y in CALL_TEMP (top 4 bits), x in OPERAND (bottom 4 bits)
        # Shift y left by 4: y * 16
        self.emit(f"ADD {self.REG_CALL_TEMP} {self.REG_CALL_TEMP} {self.REG_CALL_TEMP}")  # y * 2
        self.emit(f"ADD {self.REG_CALL_TEMP} {self.REG_CALL_TEMP} {self.REG_CALL_TEMP}")  # y * 4
        self.emit(f"ADD {self.REG_CALL_TEMP} {self.REG_CALL_TEMP} {self.REG_CALL_TEMP}")  # y * 8
        self.emit(f"ADD {self.REG_CALL_TEMP} {self.REG_CALL_TEMP} {self.REG_CALL_TEMP}")  # y * 16
        
        # OR with x to combine
        self.emit(f"XOR {self.REG_CALL_TEMP} {self.REG_OPERAND} {self.REG_ACC}")
        
        # Store to pixel address register (246)
        self.emit(f"LDI {self.REG_PTR} 246")
        self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
        
        # Handle val (pixel value)
        if isinstance(val_expr, int):
            self.emit(f"LDI {self.REG_ACC} {val_expr}")
        elif isinstance(val_expr, str):
            self.load_variable(val_expr, self.REG_ACC)
        elif isinstance(val_expr, tuple) and val_expr[0] == 'arithmetic':
            _, left, op, right = val_expr
            self.load_variable(left, self.REG_ACC)
            if isinstance(right, int):
                if op == '+':
                    self.emit(f"ADI {self.REG_ACC} {right}")
                elif op == '-':
                    complement = (256 - right) % 256
                    self.emit(f"ADI {self.REG_ACC} {complement}")
                else:
                    self.emit(f"LDI {self.REG_OPERAND} {right}")
                    self.apply_operator(op, self.REG_ACC, self.REG_OPERAND, self.REG_ACC)
            else:
                self.load_variable(right, self.REG_OPERAND)
                self.apply_operator(op, self.REG_ACC, self.REG_OPERAND, self.REG_ACC)
        
        # Store pixel value (247)
        self.emit(f"LDI {self.REG_PTR} 247")
        self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
        
        # Trigger write pixel (248)
        self.emit(f"LDI {self.REG_ACC} 1")
        self.emit(f"LDI {self.REG_PTR} 248")
        self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
        
        # IMPORTANT: Reset Write Pixel back to 0
        self.emit(f"LDI {self.REG_ACC} 0")
        self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
    
    def compile_refresh_screen(self):
        """Compile: refresh_screen() - refreshes the screen display"""
        # Memory address 249 is refresh
        self.emit(f"LDI {self.REG_ACC} 1")
        self.emit(f"LDI {self.REG_PTR} 249")
        self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
    
    def compile_clear_screen(self):
        """Compile: clear_screen() - initializes screen registers to 0"""
        # Set Draw Pixel (247) to 0
        self.emit(f"LDI {self.REG_ACC} 0")
        self.emit(f"LDI {self.REG_PTR} 247")
        self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
        
        # Set Write Pixel (248) to 0
        self.emit(f"LDI {self.REG_PTR} 248")
        self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
        
        # Set Refresh (249) to 0
        self.emit(f"LDI {self.REG_PTR} 249")
        self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
        
        # Set Reset (251) to 0
        self.emit(f"LDI {self.REG_PTR} 251")
        self.emit(f"STR {self.REG_PTR} {self.REG_ACC}")
    
    def compile_func_def(self, func_name, params, body):
        """Compile: func name(params) { body }"""
        func_label = self.new_label(f"FUNC_{func_name}")
        end_label = self.new_label(f"FUNC_{func_name}_END")
        
        # Store function info
        self.functions[func_name] = (params, body, func_label, end_label)
        
        # Jump over function definition in main code
        self.emit(f"JMP {end_label}")
        
        # Function entry point
        self.emit(func_label)
        
        # Parameters are passed via memory (addresses starting after regular variables)
        # We'll use a simple calling convention:
        # - Caller stores args to temp memory locations
        # - Function reads from those locations
        param_base = 240  # Use addresses 240-245 for parameters (max 6 params)
        
        old_in_function = self.in_function
        old_params = self.current_function_params
        self.in_function = True
        self.current_function_params = params
        
        # Map parameters to memory locations
        param_addrs = {}
        for i, param in enumerate(params):
            if i >= 6:
                raise Exception(f"Too many parameters (max 6): {func_name}")
            param_addrs[param] = param_base + i
            # Save current variable mapping
            if param in self.variables:
                param_addrs[f"_saved_{param}"] = self.variables[param]
            # Map parameter to its address
            self.variables[param] = param_base + i
        
        # Compile function body
        for statement in body:
            self.compile_statement(statement)
        
        # Restore variable mappings
        for param in params:
            if f"_saved_{param}" in param_addrs:
                self.variables[param] = param_addrs[f"_saved_{param}"]
            else:
                del self.variables[param]
        
        self.in_function = old_in_function
        self.current_function_params = old_params
        
        # Default return (return 0 if no explicit return)
        if not self.in_function:
            self.emit(f"LDI {self.REG_RETURN} 0")
        
        # Return from function
        self.emit(f"RET")
        
        # End of function
        self.emit(end_label)
    
    def compile_func_call(self, func_name, args):
        """Compile: call func(args) without assignment"""
        if func_name not in self.functions:
            raise Exception(f"Undefined function: {func_name}")
        
        params, _, func_label, _ = self.functions[func_name]
        
        if len(args) != len(params):
            raise Exception(f"Function {func_name} expects {len(params)} args, got {len(args)}")
        
        # Store arguments to parameter locations (240-245)
        param_base = 240
        for i, arg in enumerate(args):
            if isinstance(arg, int):
                # Immediate value
                self.emit(f"LDI {self.REG_CALL_TEMP} {arg}")
            else:
                # Variable
                self.load_variable(arg, self.REG_CALL_TEMP)
            
            # Store to parameter location
            self.emit(f"LDI {self.REG_PTR} {param_base + i}")
            self.emit(f"STR {self.REG_PTR} {self.REG_CALL_TEMP}")
        
        # Call function
        self.emit(f"CAL {func_label}")
    
    def compile_func_call_assign(self, result_var, func_name, args):
        """Compile: result = call func(args)"""
        # Call the function
        self.compile_func_call(func_name, args)
        
        # Store return value to result variable
        self.allocate_memory(result_var)
        self.store_variable(result_var, self.REG_RETURN)
    
    def compile_return(self, expr):
        """Compile: return expr"""
        if isinstance(expr, int):
            # Return immediate value
            self.emit(f"LDI {self.REG_RETURN} {expr}")
        elif isinstance(expr, str):
            # Return variable
            self.load_variable(expr, self.REG_RETURN)
        elif isinstance(expr, tuple) and expr[0] == 'arithmetic':
            # Return expression result
            _, left, op, right = expr
            # Compute into accumulator
            self.load_variable(left, self.REG_ACC)
            
            if isinstance(right, int):
                if op == '+':
                    self.emit(f"ADI {self.REG_ACC} {right}")
                elif op == '-':
                    complement = (256 - right) % 256
                    self.emit(f"ADI {self.REG_ACC} {complement}")
                else:
                    self.emit(f"LDI {self.REG_OPERAND} {right}")
                    self.apply_operator(op, self.REG_ACC, self.REG_OPERAND, self.REG_ACC)
            else:
                self.load_variable(right, self.REG_OPERAND)
                self.apply_operator(op, self.REG_ACC, self.REG_OPERAND, self.REG_ACC)
            
            # Move result to return register
            self.emit(f"ADD {self.REG_ACC} r0 {self.REG_RETURN}")
        
        # Return from function
        self.emit(f"RET")
    
    def apply_operator(self, op, left_reg, right_reg, dest_reg):
        """Apply an operator to two registers"""
        if op == '+':
            self.emit(f"ADD {left_reg} {right_reg} {dest_reg}")
        elif op == '-':
            self.emit(f"SUB {left_reg} {right_reg} {dest_reg}")
        elif op == '&':
            self.emit(f"AND {left_reg} {right_reg} {dest_reg}")
        elif op == '^':
            self.emit(f"XOR {left_reg} {right_reg} {dest_reg}")
        elif op == '|':
            self.emit(f"NOR {left_reg} {right_reg} {self.REG_TEMP}")
            self.emit(f"NOR {self.REG_TEMP} {self.REG_TEMP} {dest_reg}")
        else:
            raise Exception(f"Unsupported operator: {op}")
    
    def compile_if_compare(self, left_var, op, right_operand, true_block):
        """Compile: if (a < b) { ... } or if (a == 5) { ... }"""
        # Load left operand
        self.load_variable(left_var, self.REG_ACC)
        
        # Load or use right operand
        if isinstance(right_operand, int):
            self.emit(f"LDI {self.REG_OPERAND} {right_operand}")
        else:
            self.load_variable(right_operand, self.REG_OPERAND)
        
        end_label = self.new_label("IF_END")
        
        # Perform comparison: SUB sets zero flag if equal, carry flag for comparisons
        self.emit(f"SUB {self.REG_ACC} {self.REG_OPERAND} {self.REG_TEMP}")
        
        # Branch based on operator
        if op == '==':
            self.emit(f"BRH notzero {end_label}")  # Skip if not equal
        elif op == '!=':
            self.emit(f"BRH zero {end_label}")     # Skip if equal
        elif op == '<':
            self.emit(f"BRH carry {end_label}")    # Skip if >= (carry set means no borrow needed)
        elif op == '>=':
            self.emit(f"BRH notcarry {end_label}") # Skip if < (no carry means borrow needed)
        elif op == '>':
            # a > b means a-b > 0, so not zero AND carry set
            # We need: not (zero OR notcarry)
            self.emit(f"BRH zero {end_label}")     # Skip if equal
            self.emit(f"BRH notcarry {end_label}") # Skip if less than
        elif op == '<=':
            # a <= b means a-b <= 0, so zero OR notcarry
            # We need: jump if either zero OR notcarry is false (i.e., notzero AND carry)
            temp_label = self.new_label("IF_MAYBE")
            self.emit(f"BRH zero {temp_label}")    # Could be <=
            self.emit(f"BRH carry {end_label}")    # Definitely >
            self.emit(temp_label)
        
        # True block
        for statement in true_block:
            self.compile_statement(statement)
        
        self.emit(end_label)
    
    def compile_if(self, condition_var, true_block):
        """Compile: if (var != 0) { ... }"""
        # Load condition variable
        self.load_variable(condition_var, self.REG_ACC)
        
        end_label = self.new_label("IF_END")
        
        # Compare with zero - branch if zero (skip the block)
        self.emit(f"CMP {self.REG_ACC} r0")
        self.emit(f"BRH zero {end_label}")
        
        # True block
        for statement in true_block:
            self.compile_statement(statement)
        
        self.emit(end_label)
    
    def compile_ifzero(self, condition_var, true_block):
        """Compile: ifzero (var == 0) { ... }"""
        # Load condition variable
        self.load_variable(condition_var, self.REG_ACC)
        
        end_label = self.new_label("IFZERO_END")
        
        # Compare with zero - branch if NOT zero (skip the block)
        self.emit(f"CMP {self.REG_ACC} r0")
        self.emit(f"BRH notzero {end_label}")
        
        # True block (executes when variable is zero)
        for statement in true_block:
            self.compile_statement(statement)
        
        self.emit(end_label)
    
    def compile_while(self, condition_var, body_block):
        """Compile: while (var != 0) { ... }"""
        start_label = self.new_label("WHILE_START")
        end_label = self.new_label("WHILE_END")
        
        self.emit(start_label)
        
        # Load and check condition
        self.load_variable(condition_var, self.REG_ACC)
        self.emit(f"CMP {self.REG_ACC} r0")
        self.emit(f"BRH zero {end_label}")
        
        # Loop body
        for statement in body_block:
            self.compile_statement(statement)
        
        self.emit(f"JMP {start_label}")
        self.emit(end_label)
    
    def compile_while_compare(self, left_var, op, right_operand, body_block):
        """Compile: while (a < b) { ... }"""
        start_label = self.new_label("WHILE_START")
        end_label = self.new_label("WHILE_END")
        
        self.emit(start_label)
        
        # Load left operand
        self.load_variable(left_var, self.REG_ACC)
        
        # Load or use right operand
        if isinstance(right_operand, int):
            self.emit(f"LDI {self.REG_OPERAND} {right_operand}")
        else:
            self.load_variable(right_operand, self.REG_OPERAND)
        
        # Perform comparison
        self.emit(f"SUB {self.REG_ACC} {self.REG_OPERAND} {self.REG_TEMP}")
        
        # Branch to end based on operator (inverted logic - exit when condition false)
        if op == '==':
            self.emit(f"BRH notzero {end_label}")
        elif op == '!=':
            self.emit(f"BRH zero {end_label}")
        elif op == '<':
            self.emit(f"BRH carry {end_label}")
        elif op == '>=':
            self.emit(f"BRH notcarry {end_label}")
        elif op == '>':
            self.emit(f"BRH zero {end_label}")
            self.emit(f"BRH notcarry {end_label}")
        elif op == '<=':
            temp_label = self.new_label("WHILE_CONT")
            self.emit(f"BRH zero {temp_label}")
            self.emit(f"BRH carry {end_label}")
            self.emit(temp_label)
        
        # Loop body
        for statement in body_block:
            self.compile_statement(statement)
        
        self.emit(f"JMP {start_label}")
        self.emit(end_label)
    
    def compile_statement(self, statement):
        """Compile a single statement"""
        stmt_type = statement[0]
        
        if stmt_type == 'assign':
            _, var, value = statement
            self.compile_assignment(var, value)
        elif stmt_type == 'arithmetic':
            _, result, left, op, right = statement
            self.compile_arithmetic(result, left, op, right)
        elif stmt_type == 'print':
            _, var = statement
            self.compile_print(var)
        elif stmt_type == 'print_immediate':
            _, value = statement
            self.compile_print_immediate(value)
        elif stmt_type == 'print_expr':
            _, temp_var, left, op, right = statement
            self.compile_print_expr(temp_var, left, op, right)
        elif stmt_type == 'if':
            _, condition, true_block = statement
            self.compile_if(condition, true_block)
        elif stmt_type == 'if_compare':
            _, left, op, right, true_block = statement
            self.compile_if_compare(left, op, right, true_block)
        elif stmt_type == 'ifzero':
            _, condition, true_block = statement
            self.compile_ifzero(condition, true_block)
        elif stmt_type == 'while':
            _, condition, body = statement
            self.compile_while(condition, body)
        elif stmt_type == 'while_compare':
            _, left, op, right, body = statement
            self.compile_while_compare(left, op, right, body)
        elif stmt_type == 'read_controller':
            _, var = statement
            self.compile_read_controller(var)
        elif stmt_type == 'clear_display':
            self.compile_clear_display()
        elif stmt_type == 'clear_number_display':
            self.compile_clear_number_display()
        elif stmt_type == 'set_pixel':
            _, x, y, val = statement
            self.compile_set_pixel(x, y, val)
        elif stmt_type == 'refresh_screen':
            self.compile_refresh_screen()
        elif stmt_type == 'clear_screen':
            self.compile_clear_screen()
        elif stmt_type == 'func_def':
            _, func_name, params, body = statement
            self.compile_func_def(func_name, params, body)
        elif stmt_type == 'func_call':
            _, func_name, args = statement
            self.compile_func_call(func_name, args)
        elif stmt_type == 'func_call_assign':
            _, result_var, func_name, args = statement
            self.compile_func_call_assign(result_var, func_name, args)
        elif stmt_type == 'return':
            _, expr = statement
            self.compile_return(expr)
        else:
            raise Exception(f"Unknown statement type: {stmt_type}")
    
    def compile_program(self, statements):
        """Compile a complete program"""
        self.emit("# TinyLang Compiled Program")
        self.emit("")
        
        for statement in statements:
            self.compile_statement(statement)
        
        self.emit("")
        self.emit("HLT")
        
        return '\n'.join(self.assembly_code)


# This module is imported by tlc.py - no standalone execution needed
if __name__ == "__main__":
    print("This is a library module. Use tlc.py to compile TinyLang programs.")
    print("Example: python3 tlc.py myprogram.tl")
