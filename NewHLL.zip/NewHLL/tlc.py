#!/usr/bin/env python3
"""
TinyLang Compiler - Main Entry Point
Compiles .tl files to assembly for 8-bit CPU
"""

import sys
import os
from tinylang_parser import Parser
from tinylang_compiler import Compiler

def compile_file(input_file, output_file=None):
    """Compile a TinyLang file to assembly"""
    
    # Read input file
    try:
        with open(input_file, 'r') as f:
            code = f.read()
    except FileNotFoundError:
        print(f"Error: File '{input_file}' not found")
        return False
    except Exception as e:
        print(f"Error reading file: {e}")
        return False
    
    # Determine output filename
    if output_file is None:
        base_name = os.path.splitext(input_file)[0]
        output_file = base_name + ".asm"
    
    try:
        # Parse the code
        print(f"Parsing {input_file}...")
        parser = Parser()
        statements = parser.parse(code)
        print(f"  ✓ Parsed {len(statements)} statements")
        
        # Compile to assembly
        print(f"Compiling to assembly...")
        compiler = Compiler()
        assembly = compiler.compile_program(statements)
        print(f"  ✓ Generated assembly code")
        print(f"  ✓ Used {len(compiler.variables)} registers")
        
        # Write output file
        with open(output_file, 'w') as f:
            f.write(assembly)
        print(f"  ✓ Saved to {output_file}")
        
        # Show variable allocation
        if compiler.variables:
            print(f"\nVariable Memory Allocation:")
            for var, addr in compiler.variables.items():
                print(f"  {var:15} -> Memory[{addr}]")
        
        return True
        
    except Exception as e:
        print(f"Compilation error: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    if len(sys.argv) < 2:
        print("TinyLang Compiler for 8-bit CPU")
        print("\nUsage:")
        print(f"  {sys.argv[0]} <input.tl> [output.asm]")
        print("\nExample:")
        print(f"  {sys.argv[0]} program.tl")
        print(f"  {sys.argv[0]} program.tl output.asm")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None
    
    print("=" * 60)
    print("TinyLang Compiler")
    print("=" * 60)
    
    success = compile_file(input_file, output_file)
    
    print("=" * 60)
    if success:
        print("Compilation successful! ✓")
    else:
        print("Compilation failed! ✗")
        sys.exit(1)

if __name__ == "__main__":
    main()
